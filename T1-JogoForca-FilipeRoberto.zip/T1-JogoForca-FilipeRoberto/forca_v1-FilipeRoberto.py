# Aluno: Filipe Roberto

# Hangman Game (Jogo da Forca)
# Programação Orientada a Objetos

# Import
import random

# Board (tabuleiro)
board = ['''

>>>>>>>>>>Hangman<<<<<<<<<<

+---+
|   |
    |
    |
    |
    |
=========''', '''

+---+
|   |
O   |
    |
    |
    |
=========''', '''

+---+
|   |
O   |
|   |
    |
    |
=========''', '''

 +---+
 |   |
 O   |
/|   |
     |
     |
=========''', '''

 +---+
 |   |
 O   |
/|\  |
     |
     |
=========''', '''

 +---+
 |   |
 O   |
/|\  |
/    |
     |
=========''', '''

 +---+
 |   |
 O   |
/|\  |
/ \  |
     |
=========''']


# Classe
class Hangman:

    # Método Construtor
    def __init__(self, word):
        self.palavra = word
        self.palavra_secreta = self.hide_word()
        self.palavra_errada = []
        self.palavra_certa = []

    # Método para advinhar a letra
    def guess(self):
        letter = str(input())
        if not letter in self.palavra:
            self.palavra_errada.append(letter)

        else:
            self.palavra_certa.append(letter)
            positions = [indice for indice, valor in enumerate(self.palavra) if valor == letter]
            self.palavra_secreta = list(self.palavra_secreta)
            for pos in positions:
                self.palavra_secreta[pos] = letter
            self.palavra_secreta = ''.join(self.palavra_secreta)

    # Método para verificar se o jogo terminou
    def hangman_over(self):
        return self.hangman_won() or len(self.palavra_errada) > 5

    # Método para verificar se o jogador venceu
    def hangman_won(self):
        return self.palavra_secreta == self.palavra

    # Método para não mostrar a letra da palavra correta no board
    def hide_word(self):
        return '-' * len(self.palavra)

    # Método para checar o status do game e imprimir o board na tela
    def print_game_status(self):
        print(board[len(self.palavra_errada)])
        print('Palavra: {}'.format(self.palavra_secreta))
        print('Letras Erradas:')
        print(' - '.join(self.palavra_errada))
        print('Letras Corretas:')
        print(' - '.join(self.palavra_certa))
        print('Digite uma Letra: ')

# Função para ler uma palavra de forma aleatória do banco de palavras
def rand_word():
    with open("palavras.txt", "rt") as f:
        bank = f.readlines()
        return bank[random.randint(0, len(bank) - 1)].strip()


# Função Main - Execução do Programa
def main():
    # Objeto
    game = Hangman(rand_word())

    # Enquanto o jogo não tiver terminado, print do status, solicita uma letra e faz a leitura do caracter
    while not game.hangman_over():
        # Verifica o status do jogo
        game.print_game_status()
        game.guess()

    game.print_game_status()

    # De acordo com o status, imprime mensagem na tela para o usuário
    if game.hangman_won():
        print('\nParabéns! Você venceu!!')
    else:
        print('\nGame over! Você perdeu.')
        print('A palavra era ' + game.palavra)

    print('\nFoi bom jogar com você! Agora vá estudar!\n')


# Executa o programa
if __name__ == "__main__":
    main()
